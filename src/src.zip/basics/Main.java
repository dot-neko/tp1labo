package basics;
import ui.*;

import javax.swing.JFrame;




public class Main{

	public static void main(String [] args) {
		MainFrame aplicacion= new MainFrame(); 						//llamo a mainpanel
		aplicacion.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}