package entidades;

public class Turnos {

}
