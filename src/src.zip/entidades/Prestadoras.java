package entidades;

public class Prestadoras {

}
