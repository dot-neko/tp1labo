package entidades;

public class Medicos {

}
